/**
 * The ExpressJS namespace.
 * @external ExpressApplicationObject
 * @see {@link http://expressjs.com/3x/api.html#app}
 */ 

/**
 * Mobile Cloud custom code service entry point.
 * @param {external:ExpressApplicationObject}
 * service 
 */
module.exports = function(service) {


	/**
	 *  The file samples.txt in the archive that this file was packaged with contains some example code.
	 */


	service.patch('/mobile/custom/attendance/attendanceinfo/:id', function(req,res) {
		var id = req.params.id;
		if(req.body.gaishutsuTime) req.body.gaishutsuTime = req.body.gaishutsuTime.substring(1,6);
		if(req.body.modoriTime) req.body.modoriTime = req.body.modoriTime.substring(1,6);
		if(req.body.shukkinTime) req.body.shukkinTime = req.body.shukkinTime.substring(1,6);
		if(req.body.taikinTime) req.body.taikinTime = req.body.taikinTime.substring(1,6);
		var body = {
		   "Header": null,
		   "Body": {
		      "update": {
		         "arg0": {
		            "date": req.body.date,
		            "div": req.body.div,
		            "gaishutsuTime": req.body.gaishutsuTime,
		            "id": id,
		            "modoriTime": req.body.modoriTime,
		            "note": req.body.note,
		            "shukkinTime": req.body.shukkinTime,
		            "taikinTime": req.body.taikinTime,
		            "week": req.body.week
		         }
		      }
		   }
		};
		 // res.send(200, body);
		var sdk = req.oracleMobile;

	
		sdk.connectors.attendance_api.post('update', body, {inType: 'json'}).then(
		  function (result) {
		    res.send(result.statusCode, result);
		  },
		  function (error) {
		    res.send(error.statusCode, error.error);
		  }
		);
	});

	service.delete('/mobile/custom/attendance/attendanceinfo/:id', function(req,res) {
		var result = {};
		var statusCode = 200;
		res.send(statusCode, result);
	});

	service.get('/mobile/custom/attendance/attendanceinfo/:id', function(req,res) {
		var id = req.params.id;
		var body = {
		   "Header": null,
		   "Body": {
		      "getOne": {
		         "arg0": id
		      }
		   }
		};
		var sdk = req.oracleMobile;

	
		sdk.connectors.attendance_api.post('getOne', body, {inType: 'json'}).then(
		  function (result) {
		  	var json_obj = JSON.parse(result.result);
		  	var message = json_obj.Body.getOneResponse.return;
		  	if(message.shukkinTime) message.shukkinTime = "T" + message.shukkinTime + ":00";
		  	if(message.taikinTime) message.taikinTime = "T" + message.taikinTime + ":00";
		  	if(message.gaishutsuTime) message.gaishutsuTime = "T" + message.gaishutsuTime + ":00";
		  	if(message.modoriTime) message.modoriTime = "T" + message.modoriTime + ":00";
		  	message.date = formatDate(new Date(message.date), 'M/d');
		    res.send(result.statusCode, message);
		  },
		  function (error) {      
		    res.send(error.statusCode, error.error);
		  }
		);
	});

	service.post('/mobile/custom/attendance/attendanceinfo', function(req,res) {
		var result = {};
		var statusCode = 201;
		res.send(statusCode, result);
	});

	service.get('/mobile/custom/attendance/attendanceinfo', function(req,res) {
		
		var body = {
		   "Header": null,
		   "Body": {
		      "getAll": null
		   }
		};
		var sdk = req.oracleMobile;

	
		sdk.connectors.attendance_api.post('getAll', body, {inType: 'json'}).then(
		  function (result) {
		  	var json_obj = JSON.parse(result.result);
		  	var message = json_obj.Body.getAllResponse.return;
		  	for(var index in message){
				
					message[index].date = formatDate(new Date(message[index].date), 'M/d');
				
			}
		    res.send(result.statusCode, message);
		  },
		  function (error) {      
		    res.send(error.statusCode, error.error);
		  }
		);
	});

	formatDate = function  (date, format) {
	  format = format.replace(/M/g, (date.getMonth() + 1));
	  format = format.replace(/d/g, (date.getDate()));
	  return format;
	};


};
