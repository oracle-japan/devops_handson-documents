/**
 * The ExpressJS namespace.
 * @external ExpressApplicationObject
 * @see {@link http://expressjs.com/3x/api.html#app}
 */ 

/**
 * Mobile Cloud custom code service entry point.
 * @param {external:ExpressApplicationObject}
 * service 
 */
module.exports = function(service) {


	/**
	 *  The file samples.txt in the archive that this file was packaged with contains some example code.
	 */


	service.get('/mobile/custom/notice/getTodayInfo', function(req,res) {
		var sdk = req.oracleMobile;
		
		var optionsList = {};
		
		optionsList.uri = '/mobile/connector/notice_api';

		sdk.rest.get(optionsList, function (error, response, body) {
			
			if (error) {
	            res.send(500, error);
	        }else{
				var message = JSON.parse(body);
				if(message.flag && message.flag == 1){
					message.message = "本日はノー残業デーです";
				}else if(message.flag && message.flag == 2){
					message.message = "本日はプレミアムフライデーです";
				}else{
					message.message = "お知らせはありません";
				}
				res.status(response.statusCode).send(message);
			}
		});
	});

};
